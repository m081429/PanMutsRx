// -*- mode: c++; indent-tabs-mode: nil; -*-
//
// Copyright (c) 2009-2016 Illumina, Inc.
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
//

/*
 * codon_buffer.cpp
 *
 *  Created on: Sep 13, 2013
 *      Author: mkallberg
 */

#include "codon_buffer.hh"

Codon_buffer::Codon_buffer() {
//    mysample = si;
}

Codon_buffer::~Codon_buffer() {
    // TODO Auto-generated destructor stub
}

//void Codon_buffer::set_sample(starling_pos_processor::sample_info* si){
//
//}

//void Codon_buffer::set_sample(sample_info* si){
//    si->sample_size();
//}

