#!/bin/bash

rm -f ./fusion_preds.txt.post_blast_filter.info
rm -f ./fusion_preds.txt.post_blast_filter

