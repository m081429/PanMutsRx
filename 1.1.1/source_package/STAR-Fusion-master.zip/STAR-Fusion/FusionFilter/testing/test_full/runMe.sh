#!/bin/sh

../../blast_and_promiscuity_filter.pl  --fusion_preds fusion_preds.txt --out_prefix results --genome_lib_dir $CTAT_GENOME_LIB --exclude_loci_overlap_check
