rm -rf ./star_fusion_outdir
rm -rf ./star_fusion_kickstarted_outdir
