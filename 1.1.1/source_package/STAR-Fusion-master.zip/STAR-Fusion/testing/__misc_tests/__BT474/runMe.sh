../../../STAR-Fusion --left_fq test.reads_1.fastq.gz --right_fq test.reads_2.fastq.gz --genome_lib_dir /seq/regev_genome_portal/RESOURCES/CTAT_GENOME_LIB/GRCh37_gencode_v19_FL3 -O starF
