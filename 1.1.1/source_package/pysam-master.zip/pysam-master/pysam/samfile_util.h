#ifndef SAMFILE_UTIL_H
#define SAMFILE_UTIL_H

#include "htslib/sam.h"

#endif

