# pysam versioning information
__version__ = "0.12"

# TODO: upgrade number
__samtools_version__ = "1.5"

# TODO: upgrade code and number
__bcftools_version__ = "1.5"

__htslib_version__ = "1.5"
