raise ImportError('''calling "import pysam" from the source directory is not supported - please import pysam from somewhere else.''')
