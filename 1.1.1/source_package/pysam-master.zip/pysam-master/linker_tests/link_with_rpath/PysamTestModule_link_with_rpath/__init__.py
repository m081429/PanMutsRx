from PysamTestModule_link_with_rpath.BuildRead import build_read

all = ["build_read"]
