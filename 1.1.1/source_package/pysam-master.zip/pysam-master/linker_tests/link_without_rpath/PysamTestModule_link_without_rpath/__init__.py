from PysamTestModule_link_without_rpath.BuildRead import build_read

all = ["build_read"]
