/* See bufaccess.pyx */

typedef short td_h_short;
typedef double td_h_double;
typedef unsigned short td_h_ushort;
